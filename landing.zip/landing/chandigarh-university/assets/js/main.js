// this script using for mobile menu 
$(document).ready(function() {
    $('#nav-icon2').click(function() {
        $(this).toggleClass('open');
        $('.Sidenav').toggleClass('swap');
        $(".body-color-overlay").toggleClass('open');
    });

    $('.body-color-overlay').click(function() {
        $(this).toggleClass('open');
        $('.Sidenav').toggleClass('swap');
        $('#nav-icon2').removeClass('open');
    });
});

$('.body-color-overlay').click(function() {
    $(".body-color-overlay").removeClass('show');
});
// body scroll lock when menu open
function lockScroll() {
    if ($('body').hasClass('lock-scroll')) {
        $('body').removeClass('lock-scroll');
    } else {
        $('body').addClass('lock-scroll');
    }
}

//this script using for when scroll div show on footer
$(window).scroll(function() {
    if ($(window).scrollTop() >= 300) {
        $('.footer-fixed-bar').slideDown(500);
    } else {
        $('.footer-fixed-bar').slideUp(500);
    }
});

// this script using for accordion showing plus and minus when clicked
$("#accordion").on("hide.bs.collapse show.bs.collapse", e => {
    $(e.target)
        .prev()
        .find("i:last-child")
        .toggleClass("fa-minus fa-plus");
});

// this script using for nav scroll 
// Collapse Navbar
$(window).scroll(function() {
    if ($(this).scrollTop() > 0) {
        $('.custom-navbar').addClass("nav-scroll");
    } else {
        $('.custom-navbar').removeClass("nav-scroll");
    }
});
// for nav dropdown menu
$('.dropdown').hover(function() {
    $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
}, function() {
    $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
});

// hide and show 
$(document).ready(function() {
    $("#hide").click(function() {
        $("#first").hide();
    });
    $("#show").click(function() {
        $("second").show();
    });
});

// banner slider js here 
$('.banner-slider').slick({
    draggable: true,
    arrows: false,
    dots: true,
    fade: true,
    autoplaySpeed: 2000,
    autoplay: true,
    speed: 2000,
    infinite: true,
    // prevArrow: '<a class="slick-prev "><span class="icon-left-arrow "></span></a>',
    // nextArrow: '<a class="slick-next "><span class="icon-right-arrow "></span></a>',
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick "
    // instead of a settings object
});

// top 5 reason slider js here
$('.reasons-slider').slick({
    draggable: true,
    autoplay: true,
    fade: false,
    arrows: true,
    autoplaySpeed: 2000,
    infinite: true,
    prevArrow: '<a class="slick-prev"><span class="icon-left"></span></a>',
    nextArrow: '<a class="slick-next"><span class="icon-right"></span></a>',
});

//program slider js here 
$('.program-slider').slick({
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true,
    dots: false,
    arrows: true,
    autoplaySpeed: 2000,
    prevArrow: '<a class="slick-prev"><span class="icon-left"></span></a>',
    nextArrow: '<a class="slick-next"><span class="icon-right"></span></a>',
    responsive: [{
            breakpoint: 1024,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 1,
                infinite: true,
                dots: true
            }
        }, {
            breakpoint: 992,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 2
            }
        }, {
            breakpoint: 480,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }
        // You can unslick at a given breakpoint now by adding:
        // settings: "unslick"
        // instead of a settings object
    ]
});
//testimonial slider js here
$('.testimonials-slider').slick({
    infinite: true,
    autoplay: true,
    autoplaySpeed: 2000,
    slidesToShow: 1,
    slidesToScroll: 1,
    fade: true,
    prevArrow: '<a class="slick-prev"><span class="icon-left"></span></a>',
    nextArrow: '<a class="slick-next"><span class="icon-right"></span></a>',
    responsive: [{
        breakpoint: 1024,
        settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
            infinite: true,
        }
    }, {
        breakpoint: 600,
        settings: {
            slidesToShow: 1,
            slidesToScroll: 1
        }
    }, {
        breakpoint: 480,
        settings: {
            slidesToShow: 1,
            slidesToScroll: 1
        }
    }]
});

//industry leader says js here
$('.pp-slider').slick({
    infinite: true,
    autoplay: true,
    autoplaySpeed: 2000,
    slidesToShow: 4,
    slidesToScroll: 1,
    arrows: false,
    fade: false,
    prevArrow: '<a class="slick-prev"><span class="icon-left"></span></a>',
    nextArrow: '<a class="slick-next"><span class="icon-right"></span></a>',
    responsive: [{
        breakpoint: 992,
        settings: {
            slidesToShow: 3,
            slidesToScroll: 1,
            infinite: true,
        }
    }, {
        breakpoint: 768,
        settings: {
            slidesToShow: 2,
            slidesToScroll: 1
        }
    }, {
        breakpoint: 600,
        settings: {
            slidesToShow: 1,
            slidesToScroll: 1
        }
    }]
});


//benifit page randomly color changing box
setRandomClass();
setInterval(function() {
    setRandomClass();
}, 2000); //number of milliseconds (2000 = 2 seconds)

function setRandomClass() {
    var ul = $(".benifits-circle ul");
    var items = ul.find("li");
    var number = items.length;
    var random = Math.floor((Math.random() * number));
    items.removeClass("special");
    items.eq(random).addClass("special");
}